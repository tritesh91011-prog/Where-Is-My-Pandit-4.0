import type { MetadataRoute } from 'next';
export default function sitemap(): MetadataRoute.Sitemap {const base='https://whereismypandit.com';return ['','/about','/services','/book','/payment','/gallery','/testimonials','/blog','/contact','/devotee-dashboard'].map(p=>({url:base+p,lastModified:new Date(),changeFrequency:p===''?'weekly':'monthly',priority:p===''?1:.8}))}
