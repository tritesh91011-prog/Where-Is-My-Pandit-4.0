import PaymentClient from './PaymentClient';
export const metadata={title:'UPI Payment'};
export default async function Payment({searchParams}:{searchParams:Promise<Record<string,string|undefined>>}){const sp=await searchParams;return <section className="temple-pattern py-16"><div className="mx-auto max-w-7xl px-4"><PaymentClient booking={sp.booking||'WIMP-DEMO'}/></div></section>}
